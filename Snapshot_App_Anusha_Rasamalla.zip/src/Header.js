const Header = () => {
    return (

        <div className="container">
          <div className="Heading"><h1>SnapShot</h1></div>
          </div>
    )
}
export default Header;
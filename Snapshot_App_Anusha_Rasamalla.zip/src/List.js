
const List= (props) => {


    return (
           
            <div className="col-12 col-md-3 py-2">
                <div className="col px-md-0">
                    <img src={`../assets/${props.image}.jpg`} className="col" alt="Product_Image" />
                </div>
            </div>
            


    )
}
export default List;
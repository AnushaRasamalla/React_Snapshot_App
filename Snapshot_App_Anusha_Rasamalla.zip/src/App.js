import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import List from './List';
import { useState } from 'react';
function App() {
  

  const [images, setImage] = useState([
    { name: "Mountain", image: "mountain1", id: 1 },
    { name: "Mountain", image: "mountain2", id: 2 },
    { name: "Mountain", image: "mountain5", id: 3 },
    { name: "Food", image: "food2", id: 4 },
    { name: "Food", image: "food3", id: 5 },
    { name: "Food", image: "food4", id: 6 },
    { name: "Beaches", image: "beach3", id: 7 },
    { name: "Beaches", image: "beach4", id: 8 },
    { name: "Beaches", image: "beach5", id: 9 },
    { name: "Beaches", image: "beach6", id: 10 },
    { name: "Beaches", image: "beach2", id: 11 },
    { name: "Mountain", image: "mountain10", id: 12 }
  ]);

  function handleDisplay(name) {
    const newImage =images.filter(image => image.name===name);
    setImage(newImage);
    console.log(newImage);
  }

  return (

    <div className="container">
      <div className="Heading"><h1>SnapShot</h1></div>
      <div className="btn-block mb-5 mt-5">
        <button onClick={() => handleDisplay("Mountain")} type="button" class="btn btn-dark mr-3">Mountain</button>
        <button onClick={() => handleDisplay("Beaches")} type="button" class="btn btn-dark mr-3">Beaches</button>
        <button onClick={() => alert("No Matching Records")} type="button" class="btn btn-dark mr-3">Birds</button>
        <button onClick={() => handleDisplay("Food")} type="button" class="btn btn-dark mr-3">Food</button>
      </div>
      <div class="title md-3"><h4>Mountain Pictures</h4></div>
      
        <div className="container">
          <div className="row justify-content-around">

            {images.map((prod) => (
              <List image={prod.image} id={prod.name} />
            ))}
            {/*} 
            <div className="row">
            <List image="mountain1" />
      <List image="mountain2" />
      <List image="mountain5" />
      <List image="food2" />
      <List image="food3" />
      <List image="food4" />
      <List image="beach3" />
      <List image="beach4" />
      <List image="beach5" />
          <List image="beach6" />
          */}
          </div>
        </div>
      </div>
  )
        }
export default App;